obj/mm/la32_tlb.o dep/mm/la32_tlb.d: kern/mm/la32_tlb.c \
 kern/include/loongarch_tlb.h kern/include/asm/loongisa_csr.h \
 kern/include/glue_pgmap.h kern/mm/mmu.h kern/include/defs.h \
 kern/mm/memlayout.h kern/include/atomic.h kern/include/loongarch.h \
 kern/driver/intr.h kern/debug/assert.h kern/sync/sync.h \
 kern/include/list.h
