# uCore-LoongArch 32

本项目基于[ucore-thumips](https://github.com/z4yx/ucore-thumips)，将其移植到了LoongArch 32上。并成功跑通了所有的用户进程。

我们同样移植了去除答案的实验教学版本与实验指导书，实验版本位于本项目的no_answer分支，实验指导书[在此](https://cyyself.github.io/ucore_la32_docs/)。

我们已经过测试，本移植版本可以在[chiplab](https://gitee.com/loongson-edu/chiplab/)的loongarch32软核上运行。

## 编译环境准备

我们已经将实验环境打包为Docker镜像，并发布到Docker Hub，可以使用`docker pull chenyy/la32r-env`进行安装，并在该容器内完成编译即可。

## Makefile操作

### 编译内核

```shell
make
```

### 在QEMU运行内核

```shell
make qemu
```

### 调试内核

在一个终端执行以下内容，它将以debug模式启动qemu，并监听在1234端口：

```shell
make debug
```

在另一个终端启动gdb：

```shell
make gdb
```

## 效果展示

![debug](doc/img/debug.png)

## LA32与MIPS相比的一些较大改动说明

### 0. 跳转等指令不再需要软件延迟槽

这一点对于操作系统而言影响并不是很大，但是对于处理器核设计是非常重要的一点。

### 1. CP0与CSR

在LoongArch32中，CSR寄存器的作用相当于MIPS的CP0寄存器。

这里需要注意，`csrwr rd, csr_num`指令是将rd寄存器与csr_num进行对调，而非MIPS时代的`mtc0`只是单纯将值写入CP0寄存器。

### 2. 例外处理方式

在MIPS中，我们通过CP0的`Status`寄存器的`EXL`位来表示正在处理异常，因此当EXL为1时强制为内核态。

而LoongArch32的CSR中，取消了`Status`类似的寄存器，而分为了`PRMD`与`CRMD`。表示例外前状态和当前状态，而使用`ertn`指令（类似MIPS的`eret`）则会自动将`PRMD`还原到`CRMD`。这一点上比MIPS更加科学。

### 3. 存储空间管理

在MIPS架构中，我们熟悉的固定地址空间`kseg0`和`kseg1`等被舍弃。在LoongArch32中，被改为了通过CSR中的DMW寄存器配置地址映射窗口。这一部分代码位于`kern/init/entry.S`。考虑到以后可能需要在chiplab上使用PMON进行载入，因此我们按照了PMON相同的方式映射了一段内核的内存地址，也就是`0xa0000000-0xbfffffff`直接映射到`0x00000000-0x1fffffff`。而对于IO设备，以及载入用户进程需要进行的Uncached操作，配置了`0x80000000-0x9fffffff`直接映射到`0x00000000-0x1fffffff`。

对MIPS了解的同学不难看出，我们采用的配置方式非常类似于MIPS的KSEG0与KSEG1，但是对地址进行了对调。

### 4. 通用寄存器

LoongArch32中有一个比较特殊的地方，`v0`与`a0`，`v1`与`a1`寄存器尽管别名不同，但使用了相同的地址。这就导致uCore的MIPS版本原有的一些设计与它存在冲突，例如系统调用我们需要通过`a`寄存器传递参数，然后通过`v0`寄存器拿回系统的返回值。而对于一个特殊的系统调用`SYS_exec`需要通过`a`寄存器传递参数，如果我们把它的返回值直接写入`v0`会造成参数被覆盖。而由于LoongArch32中设计了8个`a`寄存器，因此这里直接将`a7`作为系统调用返回值的存储寄存器。

### 5. 系统调用

尽管LoongArch32的`syscall`指令含有15位立即数，但是在文档中并没有找到例外处理时如何读取这个系统调用号，因此这里将这一部分立即数全部设置为0。并使用`a7`寄存器传递系统调用号。

## 真实硬件运行

如果硬件未保证I-D Cache一致性，需要正确实现CACOP指令，并修改`kern/include/loongarch.h`中的缓存行大小宏定义。
---

# 2026-final: chiplab/nscscc adaptation (team T2026143250012561)

本目录为 `cyyself/ucore-loongarch32` 适配龙芯杯 LA32R 自研核 + chiplab
nscscc-team SoC 的版本。上游版本、commit 与逐处改动清单见
[PROVENANCE.md](PROVENANCE.md)；可复现构建见 `./build.sh`（产物在
`out/`：`ucore.elf` / `ucore.bin` / `ucore.elf.stripped`）。

## 平台假设

- DDR3：物理 0x1c000000，16MB 窗口；内核链接于虚拟地址 0xbc000000
  （DMWIN0 cached 窗口 0xa0000000 + 0x1c000000）。
- UART16550：物理 0x1fe001e0（经 DMWIN1 uncached 窗口访问为 0x9fe001e0）。
  **真板波特率已按 sys_clk=100MHz 修正**（rev2）：URT IP 为 24bit 小数分频
  `baud=PCLK/16/dl`，115200 需 DLL=0x36、DL3=0x40（与 sw/boot 一致，可在
  编译期用 `-DUART_PCLK=<hz>` 覆盖）；divisor=1 仅是 verilator 约定（其
  C++ UART 模型不计时），仿真构建加 `-DUCORE_VERILATOR_UART` 保留该路径。
- 稳定计数器 105MHz，时钟中断 100Hz（周期 1,050,000）。
- SoC 不接外部中断线（`intrpt[7:0]`=0）：串口输入由时钟中断里轮询。
- 核只有 DMW0/DMW1、16 项全相联 TLB、4 个 SAVE 寄存器、64B cache line；
  无 AM* 原子指令（镜像中 0 条，已 objdump 验证）、无 FPU（0 条 FP 指令）。

## 两种启动拓扑

1. **bootloader 搬运模式（默认）**：bootloader 将 `out/ucore.bin` 从暂存区
   （约定 0x1c400000）拷贝到物理 0x1c000000，DA 模式下跳转物理入口
   0x1c000000；`entry.S`  trampoline 自行完成 DA→PG 切换。
2. **PMON 模式**：监控程序配好 DMWIN0/1 并开 PG，按 ELF 虚址 0xbc000000
   载入并跳转入口 0xbc000000（trampoline 幂等，等价上游行为）。

详见 PROVENANCE.md。

## 自动构建与上板稳定性测试

### WSL USBIP 直连（已验证）

不使用 Windows `hw_server` 时，先按仓库根目录 `Readme.md` 的步骤将
`0403:6010`（JTAG）和 `0403:6001`（独立 UART）转发到 WSL、安装 cable
driver，并修复 `/dev/bus/usb/...` 与 `/dev/ttyUSB*` 权限。注意
`/dev/ttyUSB*` 只负责串口，bitstream 和 uCore 镜像仍通过 Vivado JTAG 下载。

默认端口 `3121` 若被 WSL/Windows localhost 转发层残留占用，使用 `3122`：

```shell
sudo /tools/Xilinx/Vivado/2023.2/bin/hw_server -d -s tcp::3122
```

保持服务运行，在另一个 WSL 终端执行一次冷启动验收：

```shell
HW_SERVER_URL=localhost:3122 \
UART=/dev/ttyUSB2 \
PROGRAM_BIT=each \
ROUNDS=1 \
BOOT_TIMEOUT=45 \
sh ./board_stability.sh
```

2026-08-19 已在真板验证该命令，结果为 `round 1: PASS` 和
`board stability: 1/1 passed`。对应日志位于仓库根目录
`logs/ucore-board-<时间>/`。

不要仅按编号猜测 UART。USBIP 重新 attach 后编号可能变化，应通过 VID:PID 找出
独立的 `0403:6001` 设备：

```shell
for port in /dev/ttyUSB*; do
    [ -e "$port" ] || continue
    printf '%s: ' "$port"
    udevadm info -q property -n "$port" | grep -E 'ID_VENDOR_ID|ID_MODEL_ID'
done
```

本次实板枚举为 `/dev/ttyUSB2`。`/dev/ttyUSB0` 和 `/dev/ttyUSB1` 来自
`0403:6010` 的两个 FT2232 接口，不应在本次连接中作为独立 UART 使用。

### Windows 原生 hw_server

默认脚本在本机启动 `hw_server`。如果 JTAG 由 Windows 原生 `hw_server` 管理，
在 WSL 中使用其地址：

```shell
HW_SERVER_URL=WINDOWS_HOST_IP:3121 UART=/dev/ttyUSB2 ROUNDS=1 sh ./board_stability.sh
```

远程模式不会启动 WSL 内的本地 `hw_server`；Windows 只负责 USB JTAG，WSL 仍
负责 Vivado Tcl 客户端、uCore 构建和 UART 采集。
脚本会先执行 TCP 连通性检查，成功时输出 `hw_server reachable`。

连接开发板 JTAG 和串口后，在本目录执行：

```shell
UART=/dev/ttyUSB0 ROUNDS=3 sh ./board_stability.sh
```

脚本默认完成以下步骤：

1. 启动 `hw_server`，每轮烧写 `bit/sys_test/bit/sys_soc_top_100mhz.bit`，保证 SoC 和 DDR 冷启动状态一致。
2. 调用 `build.sh` 构建并静态检查 uCore 镜像。
3. 每轮保持 CPU 复位，通过 JTAG AXI 下载 `out/ucore.bin` 到 `0x1c000000`。
4. 抽查镜像首部、中部和尾部，然后释放 CPU 并采集 115200 8N1 串口日志。
5. 要求日志同时出现 `check_boot_pgdir() succeeded` 和 `user sh is running`。

构建输出、Vivado 连接/烧录/镜像校验以及 UART 启动内容会实时显示在终端，同时
保留到 `logs/ucore-board-<时间>/`。Vivado 的大量 JTAG AXI `WRITE DATA` 仅写入
完整日志，终端只显示关键状态，避免十六进制下载内容淹没 UART 输出。未显式设置
`HW_SERVER_URL` 时，脚本复用或启动已验证的本地 `3122`。如需其他端口，必须通过
`HW_SERVER_URL=host:port` 显式指定。

每轮 Vivado 和 UART 原始日志保存在 `logs/ucore-board-<时间>/`。常用参数：

```shell
# 只在全部轮次开始前烧写一次（快速测试，不等价于冷启动稳定性测试）
PROGRAM_BIT=once UART=/dev/ttyUSB0 ROUNDS=10 sh ./board_stability.sh

# 完全跳过烧写，仅用于调试当前 FPGA 状态
PROGRAM_BIT=0 UART=/dev/ttyUSB0 ROUNDS=1 sh ./board_stability.sh

# 调整单轮启动等待时间
UART=/dev/ttyUSB0 ROUNDS=10 BOOT_TIMEOUT=45 sh ./board_stability.sh
```

## 决赛一键演示（bootloader + ucore）

决赛展示用的一键脚本、演示载荷与完整演示文档位于
[demo/](demo/)：`python demo/demo.py` 一键完成烧写 bit → bootloader
展示（ELF 加载 + fw_arg 协议）→ ucore 启动 → shell 功能演示 → UART 文件传输
往返 → 交互 shell；全部输出完整实时打印并落盘到 `logs/demo-<时间>/`。
详见 [demo/DEMO.md](demo/DEMO.md)。

## UART 文件管理与传输

完整实现说明、协议、命令和验证记录见 [UART_FILE_MANAGER.md](UART_FILE_MANAGER.md)。

当前 FPGA 镜像的 shell 提供以下内建文件命令：

```text
help
pwd
ls
mkdir data
cd data
write hello.txt hello from uCore
cat hello.txt
stat hello.txt
cp hello.txt copy.txt
mv copy.txt moved.txt
rm moved.txt
cd /
```

文件系统位于内存中的 initrd。新建和修改的文件在当前开机期间有效，复位、重新
烧写或重新加载 uCore 后会恢复为构建时内容，并不是 Flash 持久化存储。

主机向 uCore 上传文件：

```shell
python3 tools/ucore_uart.py --port /dev/ttyUSB0 put ./local.bin /local.bin
```

从 uCore 下载文件：

```shell
python3 tools/ucore_uart.py --port /dev/ttyUSB0 get /local.bin ./downloaded.bin
cmp ./local.bin ./downloaded.bin
```

传输协议使用 128 字节分块、十六进制编码、逐块 CRC32、整文件 CRC32 和逐块
ACK，适配当前无 UART 中断、由 100Hz 时钟中断轮询接收的硬件。传输期间不要再
打开其他串口终端，避免两个进程同时读取 `/dev/ttyUSB0`。

下载工具遇到超时或数据校验失败时会发送 `XCANCEL`，板端返回 `XCANCELLED` 后
关闭未完成的文件并回到 shell。若直接强制终止主机进程或拔掉 USB，取消帧无法送达，
此时需要重新启动 uCore 后再传输。

### UART shell 测试方法

一键完成自动识别 UART、启动本地 `hw_server`、烧写 bitstream、下载并启动 uCore、
检查启动日志，最后进入交互式 shell：

```shell
sh ./uart_shell.sh
```

默认使用 `localhost:3122`、自动寻找 `0403:6001` 对应的 tty，并执行一轮冷启动
验收。常用覆盖参数：

```shell
# 使用指定 UART
UART=/dev/ttyUSB2 sh ./uart_shell.sh

# 复用已经启动的 hw_server
HW_SERVER_URL=localhost:3122 sh ./uart_shell.sh

# bitstream 已烧写时跳过重新烧写，但仍通过 JTAG 下载 uCore
PROGRAM_BIT=0 sh ./uart_shell.sh
```

脚本需要 `picocom`；如果未安装，会在 uCore 启动验收通过后给出安装命令。退出
shell 使用 `Ctrl-A` 后按 `Ctrl-X`。如果脚本自行启动了 `hw_server`，退出时会将其
关闭；预先存在的 `hw_server` 不受影响。

完整自动验收优先使用上面的 `board_stability.sh`。该脚本会烧写 bitstream、下载
uCore、释放 CPU、采集 UART，并检查以下启动标志：

```text
check_boot_pgdir() succeeded
user sh is running
```

如果 uCore 已经启动，只测试交互式 shell，可使用系统已有的串口工具。例如：

```shell
sudo apt-get install picocom
picocom -b 115200 --databits 8 --parity n --stopbits 1 \
    --imap delbs /dev/ttyUSB2
```

进入 `$` 提示符后执行一组无破坏性的 shell 测试：

```text
help
pwd
mkdir uart-test
cd uart-test
write hello.txt hello from uart
cat hello.txt
stat hello.txt
cp hello.txt copy.txt
mv copy.txt moved.txt
ls
rm moved.txt
cd /
display C0DE2026
```

shell 支持 Backspace 删除当前行末字符，并会忽略方向键和 Delete 键产生的 ANSI
控制序列；当前不实现光标移动和命令历史，因此建议用 Backspace 修改输入，不要
依赖方向键编辑命令。

退出 `picocom` 使用 `Ctrl-A` 后按 `Ctrl-X`。运行文件传输工具前必须先退出所有
串口终端，否则多个进程会竞争读取同一个 UART。

只验证 UART 文件传输时，在 `sw/ucore` 目录执行：

```shell
dd if=/dev/urandom of=/tmp/ucore-uart-test.bin bs=300 count=1 status=none
python3 tools/ucore_uart.py --port /dev/ttyUSB2 put \
    /tmp/ucore-uart-test.bin /uart-test.bin
python3 tools/ucore_uart.py --port /dev/ttyUSB2 get \
    /uart-test.bin /tmp/ucore-uart-test.download.bin
cmp /tmp/ucore-uart-test.bin /tmp/ucore-uart-test.download.bin
```

`cmp` 无输出且退出码为 0 表示上传和下载内容完全一致。可用 `echo $?` 查看上一条
命令的退出码。

## 数码管显示

开发板上的小屏是 8 位十六进制七段数码管，只能显示 `0-9`、`A-F` 的组合，不能
显示任意中文、英文或图像。可在 shell 中写入 8 位十六进制值：

```text
display 1234ABCD
display C0DE2026
```

UART 文件传输会自动显示状态：`F1xxxxxx` 表示上传及已收字节数低 24 位，
`F2xxxxxx` 表示下载，`A1/A2` 表示成功，`E1/E2` 表示失败。
