# T2026143250012561 展示材料

本目录是项目展示材料的统一入口。归档根目录只包含：

- `soc/`：展示用 SoC 环境、硬件源码、bitstream 和上板工具；
- `software/`：展示用软件源码、构建工具和已生成二进制；
- `doc/`：总体说明和详细运行文档。

本次归档只更新非硬件内容：`software/` 和 `doc/`。`soc/` 中的硬件源码、
bitstream 和硬件工具保持原样，不属于本次同步范围。

## 目录内容

### soc

- `src/`：提交使用的 CPU/SoC 相关硬件源码与配置；
- `bit/func_test/`：Chiplab 功能测试 bitstream；
- `bit/sys_test/`：系统测试和 uCore 使用的 bitstream；
- `bit/perf_test/`：性能测试 bitstream；
- `tools/chiplab_func_board.tcl`：Chiplab JTAG 功能测试 Tcl；
- `chiplab_func_board.sh`：Chiplab 功能测试入口；
- `program_current_hw.tcl`：FPGA 烧写工具；
- `load_ucore_hw.tcl`：uCore JTAG 加载工具。

### software

- `boot/`：裸机启动和上板相关软件；
- `linux/`：Linux 适配源码、工具和产物；
- `ucore/`：uCore 内核、用户程序、UART 文件管理工具和可启动产物；
- `ucore/out/ucore.bin`：JTAG/bootloader 使用的原始镜像；
- `ucore/out/ucore.elf`：带调试信息的 ELF；
- `ucore/out/ucore.elf.stripped`：精简 ELF；
- `ucore/tools/ucore_uart.py`：主机 UART 文件上传下载工具。
- `ucore/uart_shell.sh`：自动烧写、启动验收并进入 UART shell 的一键脚本；
- `ucore/board_stability.sh`：实时显示构建、Vivado 关键状态和 UART 启动日志。

### doc

- `project-readme.md`：当前项目总体说明；
- `runbook.md`：软件构建和运行手册；
- `uart-file-manager.md`：UART 文件管理、协议和测试记录；
- `verified-logs/chiplab-func/`：实板通过的 Chiplab 功能测试日志；
- `verified-logs/ucore-board/`：实板通过的 uCore 构建、JTAG 和 UART 日志。

## Chiplab 功能测试

WSL 本地 `hw_server` 已使用 `3122` 实板验证。连接 JTAG 后执行：

```shell
HW_SERVER_URL=localhost:3122 sh ./chiplab_func_board.sh
```

正确结果包含：

```text
BOARD_STATUS num_data=0x3A00003A
CHIPLAB_FUNC_PASS
```

正确终态为八位数码管显示 `3A 00 00 3A`，两颗双色 LED 均为绿色。

## uCore 构建与上板

进入 `software/ucore`，一键烧写、启动并打开串口 shell：

```shell
HW_SERVER_URL=localhost:3122 UART=/dev/ttyUSB2 ./uart_shell.sh
```

脚本会自动完成构建、bitstream 烧写、uCore 下载、CPU 释放、UART 日志检查，并
在成功后进入 `picocom`。串口参数为 115200 8N1。启动成功标记：

```text
check_boot_pgdir() succeeded!
user sh is running!!!
$
```

## UART 文件管理

进入 uCore shell 后：

```text
help
pwd
ls
mkdir data
cd data
write hello.txt hello from uCore
cat hello.txt
stat hello.txt
cp hello.txt copy.txt
mv copy.txt moved.txt
rm moved.txt
```

主机上传文件：

```shell
python3 tools/ucore_uart.py --port /dev/ttyUSB2 put ./local.bin /upload.bin
```

主机下载并校验：

```shell
python3 tools/ucore_uart.py --port /dev/ttyUSB2 get /upload.bin ./downloaded.bin
cmp ./local.bin ./downloaded.bin
```

传输期间不要同时运行其他串口终端。当前 UART RX 由 100Hz 时钟中断轮询，主机
工具已经包含必要的发送限速、分块 CRC32、整文件 CRC32、ACK 和重试。

USBIP 重新 attach 后 tty 编号可能改变，应按 VID:PID 选择独立 `0403:6001`
UART；本次实板对应 `/dev/ttyUSB2`。进入 shell 后 Backspace 可正常删除，方向键和
Delete 的 ANSI 序列会被忽略，不会以 `[3~` 等文本污染命令。

## 数码管

uCore shell 可显示八位十六进制值：

```text
display C0DE2026
```

UART 传输状态码：

- `F1xxxxxx`：上传；
- `F2xxxxxx`：下载；
- `A1/A2`：成功；
- `E1/E2`：失败。

## 限制

- uCore 文件系统位于 RAM initrd，复位后恢复为构建时内容；
- 当前没有 Flash/SD 卡持久化文件系统；
- 未继续开发 ALIENTEK 4.3 英寸 TFTLCD；
- 当前显示设备仅为八位七段数码管。

更详细信息见 `runbook.md` 和 `uart-file-manager.md`。
